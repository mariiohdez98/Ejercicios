import net.bytebuddy.asm.Advice;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Ejercicio2 {

    public static final By cookiesBy = By.xpath("//*[(text()='Rechazar todo')]");
    public static final By searchBy = By.xpath("//*[@type='search']");
    public static final By wikipediaBy = By.xpath("//h3[contains(text(),'Automatización - Wikipedia')]");
    public static final By primerProcesoBy = By.xpath("//p[contains(.,'primer proceso')]");

    @Test
    public void ejercicio2() throws IOException {

        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https:/www.google.com/");
        WebElement find_cookies_button = driver.findElement(cookiesBy);
        find_cookies_button.click();
        WebElement input = driver.findElement(searchBy);
        input.click();
        input.sendKeys("Automatización");
        input.submit();

        WebElement searchAutomatizacion = driver.findElement(wikipediaBy);
        searchAutomatizacion.click();
        WebElement primer_proceso = driver.findElement(primerProcesoBy);
        primer_proceso.click();

        File screenshotFile = ((ChromeDriver) driver).getScreenshotAs(OutputType.FILE);
        ImageIO.write(ImageIO.read(screenshotFile), "png", new File("src/test/resources/wikipedia_screenshot.png"));
        driver.quit();
    }
}