import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class PetStoreAPI {

    private static final String BASE_URL = "https://petstore.swagger.io";

    public static void main(String[] args) {

        //Punto 1 -  Creación de usuarios
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce tu nombre de usuario: ");
        String username = scanner.nextLine();
        System.out.print("Introduce tu email: ");
        String email = scanner.nextLine();

        createUser(username, email);
        getUserByUsername(username);

        scanner.close();


        //Punto 2 - Listado de mascotas vendidas
        List<Pet> petsSold = getPetsByStatus("sold");
        for (Pet pet : petsSold) {
            System.out.println("ID: " + pet.getId() + ", Nombre: " + pet.getName());
        }

        //Punto 3 - Mascotas con nombres iguales
        PetCounter petCounter = new PetCounter(petsSold);
        Map<String, Integer> petCount = petCounter.countPetsByName();
        for (Map.Entry<String, Integer> entry : petCount.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    private static void createUser(String username, String email) {
        try {
            URL url = new URL(BASE_URL + "/v2/user");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            String requestBody = "{\"username\": \"" + username + "\", \"email\": \"" + email + "\"}";
            conn.getOutputStream().write(requestBody.getBytes());
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuffer response = new StringBuffer();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            System.out.println("Usuario creado correctamente");
        } catch (Exception e) {
            System.err.println("Error al crear el usuario: " + e.getMessage());
        }
    }

    private static void getUserByUsername(String username) {
        try {
            URL url = new URL(BASE_URL + "/v2/user/" + username);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuffer response = new StringBuffer();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            Gson gson = new Gson();
            JsonObject user = gson.fromJson(response.toString(), JsonObject.class);
            System.out.println("- Datos del usuario -");
            System.out.println("Nombre de usuario: " + user.get("username").getAsString());
            System.out.println("Email: " + user.get("email").getAsString());
        } catch (Exception e) {
            System.err.println("Error al obtener los datos del usuario: " + e.getMessage());
        }
    }

    private static List<Pet> getPetsByStatus(String status) {
        List<Pet> pets = new ArrayList<>();
        try {
            URL url = new URL(BASE_URL + "/v2/pet/findByStatus?status=" + status);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuffer response = new StringBuffer();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            Gson gson = new Gson();
            JsonArray petsJson = gson.fromJson(response.toString(), JsonArray.class);
            for (int i = 0; i < petsJson.size(); i++) {
                JsonObject petJson = petsJson.get(i).getAsJsonObject();
                if (petJson.get("name") != null) {
                    Pet pet = new Pet(petJson.get("id").getAsInt(), petJson.get("name").getAsString());
                    pets.add(pet);
                }
            }
        } catch (Exception e) {
            System.err.println("Error al obtener las mascotas: " + e.getMessage());
        }
        return pets;
    }
}
